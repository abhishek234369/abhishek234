package com.Assi.Assigment.services;

import java.util.ArrayList;
import java.util.List;

import com.Assi.Assigment.model.LoginInfo;

public class LoginInfoService {
	private static List<LoginInfo>  loginInfoList;
	 
	static {
		loginInfoList=new ArrayList<LoginInfo>();
		for(int i=101,count=1010101;i<=109;i++,count++){
			
		    LoginInfo info=new LoginInfo();
		        info.setUsername("abinash"+i);
		        info.setPassword("simpragma123"+count);
		        info.setEmail("abinash@simpragma.com");
		        info.setAddress("banglore");
                 
		        loginInfoList.add(info);
		        System.out.println(info);
		}
	
	}

	   public static boolean doValidate(LoginInfo loginInfo){
		      for(LoginInfo info:loginInfoList){
		    	  if(info.getUsername().equals(loginInfo.getUsername())&&
		    	(info.getPassword().equals(loginInfo.getPassword()))){
		    		   return true;
		    	  }
		      }
		   
		   return true;
	   }
	   public static boolean validateRegister(LoginInfo loginfo){
		   
		   for(LoginInfo info:loginInfoList){
		    	  if(info.getUsername().equals(loginfo.getUsername())&&
		    	(info.getPassword().equals(loginfo.getPassword())&& 
		    			info.getEmail().equals(loginfo.getEmail())
		    			&& info.getAddress().equals(loginfo.getAddress()))){
		    		   return true;
		    	  }
		      }
		   return true;
	   }
}
