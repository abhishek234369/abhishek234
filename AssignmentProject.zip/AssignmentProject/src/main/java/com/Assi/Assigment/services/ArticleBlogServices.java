package com.Assi.Assigment.services;

import java.util.ArrayList;
import java.util.List;

import com.Assi.Assigment.model.ArticleEntity;

public class ArticleBlogServices {
	private List<ArticleEntity> articleBlog;
	private static ArticleBlogServices  instance=null;
	
  public static ArticleBlogServices getInstance(){
	       if(instance==null){
	    	   instance=new ArticleBlogServices();
	       }
	   
	   return instance;
   }
   public ArticleBlogServices(){
	   articleBlog=new ArrayList<ArticleEntity>();
	   
	   articleBlog.add(new ArticleEntity("200","1", "simpragma-blog-1","Lorem ipsum dolor sit amet, consectetur "
	   		+ "adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. "
	   		+ "Ut enim ad minim veniam, quis nostrud exercitation ullamco "
	   		+ "laboris nisi ut aliquip ex ea commodo consequat. Duis aute"
	   		+ " irure dolor in reprehenderit in voluptate velit esse cillum"
	   		+ " dolore eu fugiat nulla pariatur", "abhinash"));
	   
	   articleBlog.add(new ArticleEntity("200","2", "simpragma-blog-2","Lorem ipsum dolor sit amet, "
	   		+ "consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore"
	   		+ " magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco "
	   		+ "laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in"
	   		+ " reprehenderit in voluptate velit esse cillum "
	   		+ "dolore eu fugiat nulla pariatur", "suhas" ));
	   
	   articleBlog.add(new ArticleEntity("200","3", "simpragma-blog-3","Lorem ipsum dolor sit amet,"
	   		+ " consectetur adipiscing elit,"
	   		+ " sed do eiusmod tempor incididunt ut labore et dolore"
	   		+ " magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco "
	   		+ "laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in "
	   		+ "reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur", "harish" ));
	   
	   articleBlog.add(new ArticleEntity("200","4", "simpragma-blog-3","Lorem ipsum dolor sit amet, consectetur adipiscing "
	   		+ "elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad "
	   		+ "minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo "
	   		+ "consequat. Duis aute irure dolor in "
	   		+ "reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur", "mukesh" ));
   }
   public List<ArticleEntity> fatchBlog(){
	    return articleBlog;
   }
   
   
     /* public ArticleEntity createArtice(String statusCode,String data,String title,String
    		  body,String author){
    	  ArticleEntity newarticles=new ArticleEntity(statusCode,data,title,body,author);
    	  articleBlog.add(newarticles);
    	  return newarticles;
      }*/
}
