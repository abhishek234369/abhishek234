package com.Assi.Assigment.controller;

import java.net.URI;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.Assi.Assigment.login.LoginResponse;
import com.Assi.Assigment.login.RegisterResponce;
import com.Assi.Assigment.model.LoginArticle;
import com.Assi.Assigment.model.LoginInfo;
import com.Assi.Assigment.services.ArticelServices;
import com.Assi.Assigment.services.LoginInfoService;

@RestController
public class LoginServiceController {

	@PostMapping("/login")
	public LoginResponse doLogin(@RequestBody LoginInfo loginInfo) {
		LoginResponse loginResp = new LoginResponse();
		boolean isVaLidUser;
		if (loginInfo != null) {
			isVaLidUser = LoginInfoService.doValidate(loginInfo);
			if (isVaLidUser) {

				loginResp.setStatusCode(200);
				loginResp.setMessage("success");
				loginResp.setAccessToken("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9");
			} else {
				loginResp.setStatusCode(401);
				loginResp.setMessage("unsuccess");
				loginResp.setAccessToken("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9");

			}

		}
		return loginResp;

	}

	@PostMapping("/register")
	public RegisterResponce doRegister(@RequestBody LoginInfo logininfo) {
		RegisterResponce response = new RegisterResponce();
		boolean isvalidRegister;
		if (logininfo != null) {
			isvalidRegister = LoginInfoService.validateRegister(logininfo);
			if (isvalidRegister) {
				response.setStatusCode(201);
				response.setMessage("new user created");
			} else {
				response.setStatusCode(401);
				response.setMessage("user is not created");
			}
		}
		return response;
	}

	

}
