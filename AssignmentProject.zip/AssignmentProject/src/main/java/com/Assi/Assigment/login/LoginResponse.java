package com.Assi.Assigment.login;

import java.io.Serializable;

import org.springframework.http.HttpStatus;

import com.Assi.Assigment.model.LoginInfo;

public class LoginResponse implements Serializable {
	private static final long serialVersionUId = 1L;

	// private String data;

	private int statusCode;
	// private HttpStatus StatusMsg;
	private String message;
	private String accessToken;

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public static long getSerialversionuid() {
		return serialVersionUId;
	}

}
