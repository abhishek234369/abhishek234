package com.Assi.Assigment.model;

import java.io.Serializable;

public class ArticleEntity implements Serializable {

	private String statusCode;
	private String data;
	private String title;
	private String body;
	private String author;
	
	public ArticleEntity(){
		
	}

	public ArticleEntity(String statusCode, String data,String title, String body, String author) {
		super();
		this.statusCode = statusCode;
		this.data = data;
		this.title=title;
		this.body = body;
		this.author = author;
	}
	

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public String toString() {
		return "ArticleEntity [statusCode=" + statusCode + ", "
				+ "data=" + data + ", body=" + body + ", author=" + author
				+ "]";
	}
	
}
