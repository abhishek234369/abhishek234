package com.Assi.Assigment.services;

import java.util.ArrayList;
import java.util.List;

import com.Assi.Assigment.model.LoginArticle;

public class ArticelServices {
	private static List<LoginArticle> loginArticel;
	
	static {
		   loginArticel=new ArrayList<LoginArticle>();
		        LoginArticle logArticle=new LoginArticle();
		          logArticle.setTitle("simpragma-blog");
		          logArticle.setBody("this is body blog");
		          logArticle.setAuthor("abinash");
		          logArticle.setAccess_token("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9");
		          loginArticel.add(logArticle);
		          System.out.println(logArticle);
		          
	}
	public static boolean articleValidate(LoginArticle loginArticle){
		       for(LoginArticle log:loginArticel){
		    	   if(log.getTitle().equals(loginArticle.getTitle())&&
		    		   log.getBody().equals(loginArticle.getBody())&&
		    		   log.getAuthor().equals(loginArticle.getAuthor())&&
		    		   log.getAccess_token().equals(loginArticle.getAccess_token())){
		    		   return true;
		    		   
		    	   }
		    	   
		       }
		  return true;
		
	}

}
