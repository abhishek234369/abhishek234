package com.Assi.Assigment.controller;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Assi.Assigment.login.RegisterResponce;
import com.Assi.Assigment.model.ArticleEntity;
import com.Assi.Assigment.model.LoginArticle;
import com.Assi.Assigment.services.ArticelServices;
import com.Assi.Assigment.services.ArticleBlogServices;

@RestController
public class ArticleBlogController {
   ArticleBlogServices articlesData=  ArticleBlogServices.getInstance();
   
   @GetMapping("/articles")
   public List<ArticleEntity> index(){
	    return articlesData.fatchBlog();
   }
   @PostMapping("/articles")
	public RegisterResponce doArticle(@RequestBody LoginArticle loginArticle) {
		RegisterResponce articleResponse = new RegisterResponce();
		boolean invalidArticle;
		if (loginArticle != null) {
			invalidArticle = ArticelServices.articleValidate(loginArticle);
			if (invalidArticle) {
				articleResponse.setStatusCode(201);
				articleResponse.setMessage("new Article created");
			} else {
				articleResponse.setStatusCode(401);
				articleResponse.setMessage("Article is not created");
			}
		}
		return articleResponse;
	}
}
